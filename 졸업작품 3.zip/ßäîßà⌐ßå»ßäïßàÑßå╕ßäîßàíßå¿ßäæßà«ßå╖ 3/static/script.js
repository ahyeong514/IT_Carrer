// =============================
// ✅ LocalStorage 키 정의 (★ 수정)
// =============================
const CHECKLISTS_KEY = "careerDashboard_checklists"; // (복수형으로 변경)
const REVIEWS_KEY = "careerDashboard_reviews";     // (복수형으로 변경)
const EVENTS_KEY = "careerDashboard_events";
const GOALS_KEY = "careerDashboard_goals";
const D_DAY_TITLE_KEY = "careerDashboard_dDayTitle"; // ★ 추가
const D_DAY_DATE_KEY = "careerDashboard_dDayDate";   // ★ 추가

// ★★★ 오늘의 명언 목록 (추가) ★★★
const STUDY_QUOTES = [
  "오늘 걷지 않으면, 내일은 뛰어야 한다.",
  "공부는 시간이 부족한 것이 아니라, 노력이 부족한 것이다.",
  "실패란 더 현명하게 다시 시작할 수 있는 기회일 뿐이다.",
  "나는 천천히 걷지만, 결코 뒷걸음질 치지 않는다.",
  "지금 잠을 자면 꿈을 꾸지만, 지금 공부하면 꿈을 이룬다.",
  "가장 유능한 사람은 가장 배우기 힘쓰는 사람이다.",
  "작은 노력이 쌓여 큰 성과를 이룬다.",
  "인내는 쓰지만 그 열매는 달다.",
  "배움은 끝이 없다.",
  "불가능해 보일 때까지는 항상 불가능하다.",
  "가장 큰 위험은 위험 없는 삶이다.",
  "성공의 비결은 꾸준함이다.",
  "오늘의 노력이 내일의 너를 만든다.",
  "포기하는 순간이 바로 실패하는 순간이다.",
  "천재는 1%의 영감과 99%의 노력으로 이루어진다.",
  "작은 습관이 모여 큰 차이를 만든다.",
  "어제보다 나은 오늘을 만들자.",
  "꿈을 날짜와 함께 적어놓으면 그것은 목표가 된다.",
  "가장 높은 곳에 도달하려면, 가장 낮은 곳부터 시작하라.",
  "배워서 남 주는 것이다. 아낌없이 배우자.",
  "지식에 대한 투자는 언제나 최고의 이자를 지불한다.",
  "성공은 매일 반복한 작은 노력들의 합이다.",
  "가장 어두운 시간은 해 뜨기 바로 직전이다.",
  "행동의 가치는 그 행동을 끝까지 이루는 데 있다.",
  "늦었다고 생각할 때가 가장 빠른 때이다.",
  "위대한 일은 작은 일들이 모여 이루어지는 것이다.",
  "노력은 결코 배신하지 않는다.",
  "할 수 있다고 믿는 사람은 결국 그렇게 된다.",
  "더 많이 배울수록, 더 많이 벌 수 있다.",
  "미래를 예측하는 가장 좋은 방법은 미래를 창조하는 것이다.",
  "배움에는 왕도가 없다." // 31개 (매일 다르게)
];
// ★★★★★★★★★★★★★★★★★★★★★★★★


// =============================
// ✅ 초기 데이터 (★ 수정)
// =============================
// 기본 체크리스트 (새로운 날짜에 기본값으로 사용됨)
const INITIAL_CHECKLIST = [
  { id: 1, text: "알고리즘 2문제 풀기", done: false },
  { id: 2, text: "기술 블로그 포스팅 1개", done: false },
  { id: 3, text: "'클린코드' 1챕터 읽기", done: false },
  { id: 4, text: "채용공고 5개 서칭", done: false }
];
let goals = ["대기업 입사", "AI 전문가 되기"];
let current = new Date();
let events = {};

// ★ 날짜별 데이터를 저장할 객체
let allChecklists = {};
let allReviews = {};

// ★ 현재 선택된 날짜 (기본값: 오늘)
let selectedDateKey = getTodayKey();


// =============================
// ✅ 유틸리티 함수 (★ 신규)
// =============================
/** 오늘 날짜를 "YYYY-MM-DD" 형식으로 반환 */
function getTodayKey() {
  const today = new Date();
  const year = today.getFullYear();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

// =============================
// ✅ LocalStorage 불러오기 (★ 수정)
// =============================
function loadData() {
  selectedDateKey = getTodayKey(); // ★ 항상 오늘 날짜로 시작

  // 날짜별 체크리스트 불러오기
  const savedChecklists = localStorage.getItem(CHECKLISTS_KEY);
  if (savedChecklists) {
    allChecklists = JSON.parse(savedChecklists);
  }
  // ★ 만약 오늘 날짜의 데이터가 없다면, 기본값으로 채워주기
  if (!allChecklists[selectedDateKey]) {
    // 깊은 복사를 통해 INITIAL_CHECKLIST 원본이 변경되지 않도록 함
    allChecklists[selectedDateKey] = JSON.parse(JSON.stringify(INITIAL_CHECKLIST));
  }

  // 날짜별 회고 불러오기
  const savedReviews = localStorage.getItem(REVIEWS_KEY);
  if (savedReviews) {
    allReviews = JSON.parse(savedReviews);
  }
  // ★ 기존의 회고 텍스트 로드 코드는 renderReviewForDate로 이동

  const savedEvents = localStorage.getItem(EVENTS_KEY);
  if (savedEvents) events = JSON.parse(savedEvents);

  const savedGoals = localStorage.getItem(GOALS_KEY);
  if (savedGoals) goals = JSON.parse(savedGoals);

  updateSummaryBar(); // ★ 요약 바 호출
}

// =============================
// ✅ LocalStorage 저장 (★ 수정 + 버그 수정)
// =============================
function saveChecklists() { // (이름 변경)
  localStorage.setItem(CHECKLISTS_KEY, JSON.stringify(allChecklists));
}
function saveReview() {
  const text = document.getElementById("reviewInput").value.trim();
  if (!text) {
    // ★ 저장할 텍스트가 없으면, 그냥 삭제로 간주
    delete allReviews[selectedDateKey];
    localStorage.setItem(REVIEWS_KEY, JSON.stringify(allReviews));
    renderReviewForDate(selectedDateKey); // ★ UI 새로고침 (textarea 보이기)
    document.getElementById("reviewInput").value = ""; // ★ 인풋 비우기
    return;
  }
  
  allReviews[selectedDateKey] = text; // ★ 선택된 날짜에 저장
  localStorage.setItem(REVIEWS_KEY, JSON.stringify(allReviews)); // ★ 전체 객체 저장
  
  renderReviewForDate(selectedDateKey); // ★ UI 새로고침 (textarea 숨기기)
  document.getElementById("reviewInput").value = ""; // ★ 인풋 비우기
}
function editReview() {
  const input = document.getElementById("reviewInput");
  input.style.display = "block";
  // ★ 수정: 저장된 텍스트가 없으면, 인풋을 비워줌
  input.value = allReviews[selectedDateKey] || ""; 
  input.focus(); // ★ 수정: 바로 타이핑할 수 있게 포커스
}
function deleteReview() {
  // ★ "저장" 버튼에서 텍스트 없이 호출할 수 있으므로 confirm 제거
  
  delete allReviews[selectedDateKey]; // ★ 선택된 날짜의 데이터만 삭제
  localStorage.setItem(REVIEWS_KEY, JSON.stringify(allReviews)); // ★ 전체 객체 저장
  
  renderReviewForDate(selectedDateKey); // ★ UI 새로고침 (textarea 보이기)
  document.getElementById("reviewInput").value = ""; // ★ 인풋 비우기
}
function saveEvents() {
  localStorage.setItem(EVENTS_KEY, JSON.stringify(events));
}
function saveGoals() {
  localStorage.setItem(GOALS_KEY, JSON.stringify(goals));
}

// =============================
// ✅ 핵심 목표 (수정 없음)
// =============================
function renderGoals() {
  const goalsList = document.getElementById("goalsList");
  goalsList.innerHTML = "";
  goals.forEach(goal => {
    const li = document.createElement("li");
    li.textContent = goal;
    goalsList.appendChild(li);
  });
}
function handleGoalsEdit() {
  const editBtn = document.getElementById("editGoalsBtn");
  const goalsList = document.getElementById("goalsList");
  const goalsInput = document.getElementById("goalsInput");
  if (editBtn.textContent === "수정") {
    goalsInput.value = goals.join("\n");
    goalsList.classList.add("hidden");
    goalsInput.classList.remove("hidden");
    editBtn.textContent = "저장";
  } else {
    const newGoals = goalsInput.value.split("\n").filter(g => g.trim() !== "");
    goals = newGoals;
    saveGoals();
    renderGoals();
    updateSummaryBar(); 
    goalsList.classList.remove("hidden");
    goalsInput.classList.add("hidden");
    editBtn.textContent = "수정";
  }
}

// ★★★ (신규) D-Day 수정 버튼 핸들러 ★★★
function handleDDayEdit() {
  const currentTitle = localStorage.getItem(D_DAY_TITLE_KEY) || "ADSP 시험";
  const currentDate = localStorage.getItem(D_DAY_DATE_KEY) || "2025-11-20";

  const newTitle = prompt("D-Day 제목을 입력하세요:", currentTitle);
  if (!newTitle) return; // 사용자가 취소한 경우

  const newDate = prompt("D-Day 날짜를 입력하세요 (YYYY-MM-DD):", currentDate);
  if (!newDate) return; // 사용자가 취소한 경우

  // 날짜 유효성 검사
  if (new Date(newDate).toString() === "Invalid Date") {
    alert("잘못된 날짜 형식입니다. YYYY-MM-DD 형식으로 입력해주세요.");
    return;
  }

  // localStorage에 저장
  localStorage.setItem(D_DAY_TITLE_KEY, newTitle);
  localStorage.setItem(D_DAY_DATE_KEY, newDate);

  // 요약 바 새로고침
  updateSummaryBar();
}

// =============================
// ✅ 요약 바 업데이트 (★ D-Day 로드 + 명언 기능으로 수정됨)
// =============================
function updateSummaryBar() {
  // 1. D-Day (★ localStorage에서 불러오기)
  const dDayTitle = localStorage.getItem(D_DAY_TITLE_KEY) || "ADSP 시험";
  const dDayDateStr = localStorage.getItem(D_DAY_DATE_KEY) || "2025-11-20"; // 기본값
  
  const targetDate = new Date(dDayDateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0); // 시간은 0시로 통일
  
  let diffDays = 0;
  if (targetDate.toString() !== "Invalid Date") {
    const diffTime = targetDate - today;
    diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }
  
  const dDayElem = document.getElementById("d-day-counter");
  const dDayTitleElem = document.getElementById("d-day-title-elem"); 
  
  dDayTitleElem.textContent = `D-Day (${dDayTitle})`; // 제목 업데이트
  if (diffDays > 0) dDayElem.textContent = `D-${diffDays}`;
  else if (diffDays === 0) dDayElem.textContent = "D-Day";
  else dDayElem.textContent = "종료";

  // 2. 오늘의 진척도 (링)
  const todayKey = getTodayKey();
  const todayItems = allChecklists[todayKey] || [];
  const doneCount = todayItems.filter(item => item.done).length;
  const totalCount = todayItems.length;
  
  let percentage = 0;
  if (totalCount > 0) {
    percentage = (doneCount / totalCount) * 100;
  }
  
  const ring = document.getElementById("today-progress-ring");
  const text = document.getElementById("today-progress-text");
  
  const circumference = 2 * Math.PI * 36;
  const offset = circumference - (percentage / 100) * circumference;
  
  ring.style.strokeDashoffset = offset;
  text.textContent = `${doneCount}/${totalCount}`;

  // 3. 오늘의 명언 (★ 수정된 부분)
  const day = today.getDate(); // 오늘 날짜 (1~31)
  const index = (day - 1) % STUDY_QUOTES.length; 
  const todayQuote = STUDY_QUOTES[index];
  
  document.getElementById("quote-of-the-day").textContent = todayQuote;
}
// =============================
// ✅ 체크리스트 (★ 대폭 수정)
// (날짜별 렌더링 함수와 날짜 선택 함수 추가)
// =============================

/** (★ 신규 + 제목 수정) 특정 날짜의 UI (제목, 체크리스트, 회고)를 렌더링 */
function renderDataForDate(dateKey) {
  selectedDateKey = dateKey; // ★ 현재 선택된 날짜 업데이트
  
  const isToday = (dateKey === getTodayKey());
  let displayDate; // ★ let으로 변경
  
  if (isToday) {
    displayDate = "오늘";
  } else {
    // "YYYY-MM-DD"에서 "DD" 부분만 추출
    const day = dateKey.split('-')[2];
    // "08" -> 8, "23" -> 23
    const dayNumber = parseInt(day, 10); 
    displayDate = `${dayNumber}일`;
  }

  // 제목 업데이트
  document.getElementById("selectedDateDisplay").textContent = displayDate;
  document.getElementById("selectedDateDisplayReview").textContent = displayDate;

  // 데이터 렌더링
  renderChecklistForDate(dateKey);
  renderReviewForDate(dateKey);
}

/** (★ 신규) 특정 날짜의 체크리스트 렌더링 */
function renderChecklistForDate(dateKey) {
  const container = document.getElementById("checklist");
  container.innerHTML = "";
  
  // ★ 선택된 날짜의 체크리스트 (없으면 빈 배열)
  const items = allChecklists[dateKey] || [];

  if (items.length === 0) {
    container.innerHTML = "<p class='empty-data-msg'>이 날짜의 체크리스트가 없습니다.</p>";
    return;
  }

  items.forEach(item => {
    const row = document.createElement("div");
    row.className = "checklist-item-row";

    const left = document.createElement("div");
    left.style.display = "flex";
    left.style.alignItems = "center";
    left.style.gap = "8px";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = item.done;
    checkbox.onchange = () => toggleTask(item.id);

    const span = document.createElement("span");
    span.textContent = item.text;
    if (item.done) span.classList.add("done");

    left.appendChild(checkbox);
    left.appendChild(span);

    const btnGroup = document.createElement("div");
    btnGroup.className = "checklist-btn-group";

    const editBtn = document.createElement("button");
    editBtn.textContent = "수정";
    editBtn.className = "mini-checklist-btn";
    editBtn.onclick = () => editTask(item.id, span);

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "삭제";
    deleteBtn.className = "mini-checklist-btn";
    deleteBtn.onclick = () => deleteTask(item.id);

    btnGroup.appendChild(editBtn);
    btnGroup.appendChild(deleteBtn);

    row.appendChild(left);
    row.appendChild(btnGroup);

    container.appendChild(row);
  });
}

/** (★ 신규 + 버그 수정) 특정 날짜의 회고 렌더링 */
function renderReviewForDate(dateKey) {
  const reviewText = document.getElementById("reviewText");
  const reviewInput = document.getElementById("reviewInput");
  
  const savedText = allReviews[dateKey] || "";
  reviewText.textContent = savedText;

  // ★ 수정: 여기서는 visibility(보임/숨김)만 제어
  if (savedText) {
    reviewInput.style.display = "none";
  } else {
    reviewInput.style.display = "block";
  }
}

// --- 기존 체크리스트 함수들 (★ 수정) ---

function toggleTask(id) {
  // ★ 선택된 날짜의 아이템을 가져옴
  let items = allChecklists[selectedDateKey] || [];
  items = items.map(item =>
    item.id === id ? { ...item, done: !item.done } : item
  );
  allChecklists[selectedDateKey] = items; // ★ 다시 저장
  
  renderChecklistForDate(selectedDateKey); // ★ 새로고침
  saveChecklists();
  updateSummaryBar(); // ★ 요약 바 호출
}
function addTask() {
  const input = document.getElementById("newTask");
  const text = input.value.trim();
  if (!text) return;
  const newItem = { id: Date.now(), text, done: false };
  
  // ★ 선택된 날짜의 배열이 없으면 생성
  if (!allChecklists[selectedDateKey]) {
    allChecklists[selectedDateKey] = [];
  }
  allChecklists[selectedDateKey].push(newItem); // ★ 선택된 날짜에 추가
  
  input.value = "";
  renderChecklistForDate(selectedDateKey); // ★ 새로고침
  saveChecklists();
  updateSummaryBar(); // ★ 요약 바 호출
}
function editTask(id, spanElem) {
  const newText = prompt("수정할 내용을 입력하세요", spanElem.textContent);
  if (newText && newText.trim() !== "") {
    // ★ 선택된 날짜의 아이템을 가져옴
    let items = allChecklists[selectedDateKey] || [];
    items = items.map(item =>
      item.id === id ? { ...item, text: newText.trim() } : item
    );
    allChecklists[selectedDateKey] = items; // ★ 다시 저장
    
    renderChecklistForDate(selectedDateKey); // ★ 새로고침
    saveChecklists();
    // (Edit은 진척도 카운트에 영향 없으므로 updateSummaryBar 호출 불필요)
  }
}
function deleteTask(id) {
  if (!confirm("체크리스트 항목을 삭제하시겠습니까?")) return;
  
  // ★ 선택된 날짜의 아이템을 가져옴
  let items = allChecklists[selectedDateKey] || [];
  items = items.filter(item => item.id !== id);
  allChecklists[selectedDateKey] = items; // ★ 다시 저장

  renderChecklistForDate(selectedDateKey); // ★ 새로고침
  saveChecklists();
  updateSummaryBar(); // ★ 요약 바 호출
}

// =============================
// ✅ 이벤트 (일정 클릭 시 수정/삭제 선택 모달 표시)
// (★ renderCalendar 내부 수정)
// =============================
function addEvent(dateKey) {
  const title = prompt("일정을 입력하세요 (예: 면접)");
  if (!title) return;
  const endDateInput = prompt("종료 날짜를 입력하세요 (예: 2025-09-25) / 단일 일정이면 그냥 Enter");
  if (!endDateInput) {
    if (!events[dateKey]) events[dateKey] = [];
    events[dateKey].push(title);
  } else {
    try {
      const start = new Date(dateKey);
      const end = new Date(endDateInput);
      if (start > end) {
        alert("종료 날짜는 시작 날짜보다 빠를 수 없습니다.");
        return;
      }
      let currentDay = new Date(start);
      while (currentDay <= end) {
        const key = `${currentDay.getFullYear()}-${String(currentDay.getMonth() + 1).padStart(2, "0")}-${String(currentDay.getDate()).padStart(2, "0")}`;
        if (!events[key]) events[key] = [];
        events[key].push(title);
        currentDay.setDate(currentDay.getDate() + 1);
      }
    } catch(e) {
      alert("유효한 날짜 형식이 아닙니다. (YYYY-MM-DD)");
      return;
    }
  }
  saveEvents();
  renderCalendar();
}

function deleteEvent(dateKey, eventTitle) {
  const eventArray = events[dateKey];
  if (!eventArray) return;
  const eventIndex = eventArray.indexOf(eventTitle);
  if (eventIndex > -1) {
    eventArray.splice(eventIndex, 1);
    if (events[dateKey].length === 0) delete events[dateKey];
  }
  saveEvents();
  renderCalendar();
}

function renderCalendar() {
  const year = current.getFullYear();
  const month = current.getMonth();
  const monthNames = ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"];
  document.querySelector(".month-nav h3").textContent = `${year}년 ${monthNames[month]}`;
  const grid = document.querySelector(".calendar .grid");
  grid.innerHTML = "";
  ["일","월","화","수","목","금","토"].forEach(day => {
    const div = document.createElement("div");
    div.className = "day-header";
    div.textContent = day;
    grid.appendChild(div);
  });
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  for (let i = 0; i < firstDay; i++) {
    const cell = document.createElement("div");
    cell.className = "cell empty";
    grid.appendChild(cell);
  }

  const today = new Date(); // ★ 오늘 날짜 확인용

  for (let d = 1; d <= daysInMonth; d++) {
    const cell = document.createElement("div");
    cell.className = "cell";
    const dateNum = document.createElement('span');
    dateNum.textContent = d;
    cell.appendChild(dateNum);
    const dateKey = `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

    // ★ 1. 오늘 날짜 하이라이트
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) {
      cell.classList.add("today");
    }

    if (events[dateKey]) {
      const ul = document.createElement("ul");
      events[dateKey].forEach(ev => {
        const li = document.createElement("li");
        li.textContent = ev;
        li.style.cursor = "pointer";

        // 일정 클릭 시 수정/삭제 모달 표시 이벤트 추가
        li.onclick = function(e) {
          e.stopPropagation();

          // ... (기존 모달 로직 동일) ...
          const existingModal = document.querySelector(".event-action-modal");
          if (existingModal) existingModal.remove();
          const modal = document.createElement("div");
          modal.className = "event-action-modal";
          const btnEdit = document.createElement("button");
          btnEdit.textContent = "수정";
          btnEdit.onclick = () => {
            const newTitle = prompt("새 일정명을 입력하세요", ev);
            if (newTitle && newTitle.trim() && newTitle !== ev) {
              const idx = events[dateKey].indexOf(ev);
              if (idx > -1) {
                events[dateKey][idx] = newTitle.trim();
                saveEvents();
                renderCalendar();
              }
            }
            modal.remove();
          };
          const btnDelete = document.createElement("button");
          btnDelete.textContent = "삭제";
          btnDelete.onclick = () => {
            if (confirm(`'${ev}' 일정을 삭제하시겠습니까?`)) {
              deleteEvent(dateKey, ev);
            }
            modal.remove();
          };
          modal.appendChild(btnEdit);
          modal.appendChild(btnDelete);
          const rect = li.getBoundingClientRect();
          modal.style.position = "absolute";
          modal.style.top = `${rect.bottom + window.scrollY}px`;
          modal.style.left = `${rect.left + window.scrollX}px`;
          modal.style.zIndex = 10000;
          document.body.appendChild(modal);
          function onClickOutside(event) {
            if (!modal.contains(event.target)) {
              modal.remove();
              document.removeEventListener('click', onClickOutside);
            }
          }
          setTimeout(() => document.addEventListener('click', onClickOutside), 1);
        };

        ul.appendChild(li);
      });
      cell.appendChild(ul);
    }
    
    // ★ 2. 클릭 이벤트 분리
    // (기존) cell.onclick = () => addEvent(dateKey);
    // (변경) cell(날짜 칸)을 클릭하면 데이터 로드
    //        dateNum(날짜 숫자)을 클릭하면 일정 추가
    
    cell.onclick = () => renderDataForDate(dateKey);
    dateNum.onclick = (e) => {
      e.stopPropagation(); // 부모(cell)의 클릭 이벤트 방지
      addEvent(dateKey);
    };

    grid.appendChild(cell);
  }
}
function prevMonth() {
  current.setMonth(current.getMonth() - 1);
  renderCalendar();
}
function nextMonth() {
  current.setMonth(current.getMonth() + 1);
  renderCalendar();
}

// =============================
// ✅ 초기 실행 (★ 수정)
// =============================
loadData(); // (updateSummaryBar가 이 안에 포함됨)
renderCalendar();
renderGoals();
// ★ renderChecklist() 대신 renderDataForDate(오늘날짜) 호출
renderDataForDate(getTodayKey()); 

document.getElementById("prevBtn").onclick = prevMonth;
document.getElementById("nextBtn").onclick = nextMonth;
document.getElementById("editGoalsBtn").onclick = handleGoalsEdit;
document.getElementById("editDDayBtn").onclick = handleDDayEdit; // ★ 추가