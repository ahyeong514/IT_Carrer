import chromadb
import os
import sys # 프로그램 종료를 위해 추가

# --- 이 스크립트는 이제 어떤 경로의 DB든 확인할 수 있습니다 ---

# 1. 사용자에게 데이터베이스 경로 물어보기
db_path = input("👉 확인하고 싶은 chroma_db 폴더의 전체 경로를 입력하고 Enter를 누르세요:\n") # <<< 수정된 부분

# 2. 입력된 경로가 실제로 존재하는지 확인
if not os.path.exists(db_path) or not os.path.isdir(db_path): # <<< 추가된 부분
    print(f"\n❌ 오류: '{db_path}' 경로를 찾을 수 없거나 폴더가 아닙니다.")
    print("파일 탐색기에서 폴더를 우클릭하여 '경로로 복사' 후 붙여넣어 보세요.")
    sys.exit() # 경로가 없으면 프로그램 종료

# 3. 사용자에게 컬렉션 이름 물어보기
collection_name = input(f"\n👉 '{os.path.basename(db_path)}' DB에서 확인할 컬렉션 이름을 입력하세요 (예: pdf_chatbot_collection):\n") # <<< 추가된 부분

print("-" * 50)
print(f"🔍 '{db_path}' 경로의 데이터베이스를 확인합니다...")
print(f"📚 컬렉션 이름: '{collection_name}'")

# 4. ChromaDB 클라이언트 연결 (사용자가 입력한 경로 사용)
client = chromadb.PersistentClient(path=db_path) # <<< 수정된 부분

try:
    # 5. 컬렉션 가져오기 (사용자가 입력한 이름 사용)
    collection = client.get_collection(name=collection_name) # <<< 수정된 부분
    
    # 6. 컬렉션의 모든 데이터 가져오기
    all_data = collection.get(include=["documents"])

    # 7. 결과 출력하기
    documents = all_data['documents']
    ids = all_data['ids']
    
    print(f"\n✅ 총 {collection.count()}개의 문서 조각을 찾았습니다. 내용은 아래와 같습니다.\n")
    print("-" * 50)

    for i, doc_text in enumerate(documents):
        preview = (doc_text[:150] + '...') if len(doc_text) > 150 else doc_text
        print(f"📌 [ID: {ids[i]}]")
        print(f"{preview}\n")

except ValueError:
    print(f"\n❌ 오류: '{collection_name}' 컬렉션을 찾을 수 없습니다. 이름이 정확한지 확인해주세요.")
except Exception as e:
    print(f"\n❌ 오류가 발생했습니다: {e}")