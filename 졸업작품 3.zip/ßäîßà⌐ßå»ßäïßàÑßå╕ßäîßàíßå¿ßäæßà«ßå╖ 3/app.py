# -*- coding: utf-8 -*-

# === 1. 라이브러리 임포트 ===
import os
import re
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import fitz  # PDF 처리를 위한 PyMuPDF
import ollama
import chromadb
from sentence_transformers import SentenceTransformer
import urllib.request # 뉴스 API가 사용하는 라이브러리
import json # 뉴스 API가 사용하는 라이브러리
import traceback # 상세 오류 로깅을 위한 라이브러리 추가

# 네이버 API 인증 정보
CLIENT_ID = "Gsw3EKqttspCGXo8GXUr"
CLIENT_SECRET = "Nd76GbAAKv"

# === 2. Flask 앱 초기화 ===
app = Flask(__name__)
CORS(app)  # Cross-Origin Resource Sharing (CORS) 활성화

# === 3. 설정 변수 ===
# --- 이 스크립트가 위치한 디렉토리의 절대 경로를 가져옵니다
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- 리소스의 절대 경로를 설정합니다
PDF_FILE_PATH = os.path.join(BASE_DIR, "job.pdf")
CHROMA_DB_PATH = os.path.join(BASE_DIR, "chroma_db")

# --- 모델 및 RAG 설정
MODEL_NAME = "exaone3.5:2.4b"
# ChromaDB 컬렉션의 이름입니다.
CHROMA_DB_PATH = "./chroma_db"
CHROMA_COLLECTION_NAME = "pdf_chatbot_collection"
# 임베딩 생성을 위한 Sentence Transformer 모델입니다.
EMBEDDING_MODEL_NAME = "intfloat/multilingual-e5-small"
# 데이터베이스에서 가져올 관련성 높은 청크의 수입니다.
TOP_K_CHUNKS = 10

# === 4. RAG 시스템을 위한 전역 변수 ===
# 서버가 시작될 때 한 번 초기화됩니다.
embedder = None
chroma_collection = None

# === 5. RAG 시스템 핵심 함수 ===

def read_pdf_chunks(file_path, chunk_size=1000, overlap=200):
    if not os.path.exists(file_path):
        print(f"❌ 오류: '{file_path}' 파일을 찾을 수 없습니다.")
        return []
    try:
        doc = fitz.open(file_path)
        full_text = ""
        for page in doc:
            full_text += page.get_text("text")
        doc.close()
        full_text = re.sub(r'\s+', ' ', full_text).strip()
        chunks = []
        for i in range(0, len(full_text), chunk_size - overlap):
            chunks.append(full_text[i:i + chunk_size])
        return chunks
    except Exception as e:
        print(f"❌ PDF 파일 처리 중 오류 발생: {e}")
        return []

def initialize_rag_system():
    global embedder, chroma_collection
    print("🚀 RAG 시스템 초기화 시작...")
    try:
        embedder = SentenceTransformer("intfloat/multilingual-e5-small")
        print("✅ 임베딩 모델 로드 완료.")
        client = chromadb.PersistentClient(path=CHROMA_DB_PATH)
        chroma_collection = client.get_or_create_collection(name=CHROMA_COLLECTION_NAME)
        if chroma_collection.count() == 0:
            print(f"⚠️ 데이터베이스가 비어있습니다. '{PDF_FILE_PATH}' 파일에서 데이터를 로드합니다...")
            pdf_chunks = read_pdf_chunks(PDF_FILE_PATH)
            if not pdf_chunks:
                print(f"❌ PDF 파일 '{PDF_FILE_PATH}'을 읽는 데 실패했거나 내용이 없습니다.")
                return
            chunk_embeddings = embedder.encode(pdf_chunks, show_progress_bar=True)
            ids = [str(i) for i in range(len(pdf_chunks))]
            chroma_collection.add(embeddings=chunk_embeddings, documents=pdf_chunks, ids=ids)
            print(f"✅ PDF 문서가 데이터베이스에 저장되었습니다. ({len(pdf_chunks)}개 조각)")
        else:
            print(f"✅ 기존 데이터베이스에서 {chroma_collection.count()}개의 임베딩을 로드했습니다.")
        print("🎉 RAG 시스템이 준비되었습니다.")
    except Exception as e:
        print(f"❌ RAG 초기화 중 심각한 오류 발생: {e}")

# --- 5. 핵심 LLM 및 프롬프트 로직 ---
BASE_SYSTEM_MESSAGE = {"role": "system", "content": "당신은 제공된 문서의 컨텍스트(context)만을 기반으로 질문에 답변하는 지능형 어시스턴트입니다. 답변은 반드시 한국어로 해야 합니다. 'CONTEXT' 섹션에 주어진 정보를 사용하여 사용자의 질문에 간결하고 직접적으로 답변하세요. 만약 컨텍스트에 답변이 포함되어 있지 않다면, 반드시 '주어진 문서 내용으로는 답변할 수 없습니다.'라고 말해야 합니다. 외부 지식을 절대 사용하지 마세요. **, ##, 또는 목록과 같은 마크다운 서식을 사용하지 마세요."}
def run_ollama_chat(question, history):
    """
    RAG(검색 증강 생성) 파이프라인을 실행하여 질문에 답변하는 메인 함수
    (PDF 문서 검색 기능 활성화 버전)
    """
    if chroma_collection is None:
        return "오류: RAG 시스템이 초기화되지 않았습니다. 서버 로그를 확인해주세요."
    
    # 1. ChromaDB에서 관련 문서 조각(청크) 검색
    try:
        results = chroma_collection.query(query_texts=[question], n_results=TOP_K_CHUNKS)
        
        # 검색된 문서가 있는지 확인
        if not results or not results.get('documents') or not results['documents'][0]:
            return "주어진 문서에서 질문과 관련된 정보를 찾을 수 없었습니다."

        top_chunks = results['documents'][0]
        context = "\n---\n".join(top_chunks)

        # 검색된 내용이 비어있는지 확인
        if not context.strip():
            return "관련 정보를 찾았지만 내용이 비어있어 답변할 수 없습니다."
            
    except Exception as e:
        print(f"❌ ChromaDB 검색 중 오류 발생: {e}")
        traceback.print_exc()
        return f"문서 데이터베이스를 검색하는 중 오류가 발생했습니다: {str(e)}"

    # 2. LLM에 전달할 프롬프트 구성
    messages = [BASE_SYSTEM_MESSAGE]
    messages.extend(history)
    
    prompt_with_context = f"""
아래의 [CONTEXT]를 참고하여 사용자의 [QUESTION]에 대해 한국어로 답변해 주세요.

[CONTEXT]
{context}

[QUESTION]
{question}
"""
    messages.append({"role": "user", "content": prompt_with_context})
    
    # 3. Ollama LLM 호출 및 답변 받기
    try:
        response = ollama.chat(model=MODEL_NAME, messages=messages)
        answer = response["message"]["content"].strip()
        answer = re.sub(r'[\*\*#*-]', '', answer).strip()
        return answer
    except Exception as e:
        print(f"❌ Ollama API에서 심각한 오류 발생: {e}")
        traceback.print_exc()
        return f"드디어 진짜 원인을 찾았습니다: {str(e)}"
    
def get_it_jobs():
    """네이버 '블로그' 검색 API를 이용해 'IT 채용' 관련 포스팅을 가져오는 함수"""
    try:
        encText = urllib.parse.quote("IT 채용 공고")
        url = "https://openapi.naver.com/v1/search/blog?query=" + encText + "&display=5&sort=sim"
        request_obj = urllib.request.Request(url)
        request_obj.add_header("X-Naver-Client-Id", CLIENT_ID)
        request_obj.add_header("X-Naver-Client-Secret", CLIENT_SECRET)

        response = urllib.request.urlopen(request_obj)
        rescode = response.getcode()

        if rescode == 200:
            response_body = response.read().decode('utf-8')
            blog_data = json.loads(response_body)

            postings = []
            for item in blog_data['items']:
                title = item['title'].replace('<b>', '').replace('</b>', '')
                link = item['link']
                postings.append({'title': title, 'link': link})

            return postings
        else:
            return []
    except Exception as e:
        print(f"블로그 포스팅 검색 중 에러 발생: {e}")
        return []

def get_it_news():
    """네이버 뉴스 API를 호출하여 IT 뉴스 20개를 가져오는 함수"""
    try:
        encText = urllib.parse.quote("IT 직종")
        url = "https://openapi.naver.com/v1/search/news?query=" + encText + "&display=20&sort=sim"

        request_obj = urllib.request.Request(url)
        request_obj.add_header("X-Naver-Client-Id", CLIENT_ID)
        request_obj.add_header("X-Naver-Client-Secret", CLIENT_SECRET)

        response = urllib.request.urlopen(request_obj)
        rescode = response.getcode()

        if rescode == 200:
            response_body = response.read().decode('utf-8')
            news_data = json.loads(response_body)

            articles = []
            for item in news_data['items']:
                title = item['title'].replace('<b>', '').replace('</b>', '')
                link = item['link']
                articles.append({'title': title, 'link': link})

            return articles
        else:
            return []
    except Exception as e:
        print(f"Error fetching news: {e}")
        return []

# === 6. Flask API 엔드포인트 (라우트) ===

@app.route('/')
def home():
    news_articles = get_it_news()   # 기존 뉴스 크롤링 함수
    job_postings = get_it_jobs()    # 새로 추가한 채용 공고 크롤링 함수

    return render_template(
        'home.html',
        news_list=news_articles,
        job_list=job_postings   # job_list 라는 이름으로 채용 공고 데이터를 전달
    )

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

@app.route('/taja')
def taja():
    return render_template('taja.html')

@app.route('/IT')
def IT(): 
    return render_template('IT.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/ask', methods=['POST'])
def ask_chatbot():
    """ 챗봇을 위한 메인 API 엔드포인트입니다. """
    if embedder is None or chroma_collection is None:
        return jsonify({"error": "RAG 시스템이 준비되지 않았습니다."}), 500

    data = request.json
    question = data.get('question', '')
    history = data.get('history', [])

    if not question:
        return jsonify({"error": "질문이 제공되지 않았습니다."}), 400

    answer = run_ollama_chat(question, history)

    # 다음 차례를 위해 대화 기록을 업데이트합니다.
    updated_history = history + [{"role": "user", "content": question}, {"role": "assistant", "content": answer}]

    return jsonify({"answer": answer, "history": updated_history})


# === 7. 메인 실행 블록 ===
if __name__ == "__main__":
    initialize_rag_system()
    print(f"💬 Flask 서버가 http://localhost:5000 에서 시작됩니다. 모델: {MODEL_NAME}")
    app.run(host='0.0.0.0', port=5000, debug=True)

